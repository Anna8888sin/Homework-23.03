import java.util.Random;
import java.util.Scanner;

public class Main {
    /*
     Все задания можно выполнить в одном проекте.
     1 Пользователь вводит число. Если число больше 0, то выполнить следующие операции:
 - умножить число на 2, если оно нечётное;
 - прибавить к числу 5, если если оно заканчивается на 5 или 0.
Если число < 0, то взять его по модулю и разделить на 3.
Результат вычисления вывести в консоль.
     2 Пользователь вводит строку. Если строка начинается с цифры (0, 1, 2, 3, 4, 5, 6 , 7, 8, 9),
то вывести эту цифру в консоль. Если строка начинается со знака _ или знака -, то вывести в консоль
строку без этого знака. Используйте методы startsWith, charAt и substring.
     3 Пользователь вводит два числа. Если они не равны, то вывести в консоль их сумму,
иначе вывести их произведение. Используйте тернарный оператор.
     4 С помощью Random сгенерируйте три числа. Напишите программу, которая находит максимальное из них.
 Используйте тернарные операторы.*/

    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        Random rnd = new Random();

        // Задание 1
        System.out.println("Введите число: ");
        int a = scn.nextInt();

            System.out.println("Умножаем на 2: " + a * 2);

        if (a % 10 == 5 || a % 10 == 0 && a > 0) {
            System.out.println("Прибавляем 5: " + (a + 5));
        }
        if (a < 0) {
            System.out.println(Math.abs(a) % 3);
        }

        // Задание 2
        System.out.print("Введите строку: ");
        String str = scn.next();
        if (str.charAt(0) >= '0' && str.charAt(0) <= '9') {
            System.out.println("Первый символ является цифрой: " + str.charAt(0));
        } else if (str.startsWith("_") || str.startsWith("-")) {
            System.out.println("Строка без первого символа: " + str.substring(1));
        }

        // Задание 3
        System.out.print("Введите два числа: ");
        int num1 = scn.nextInt();
        int num2 = scn.nextInt();
        int result = (num1 != num2) ? (num1 + num2) : (num1 * num2);
        System.out.println("Результат вычисления: " + result);

        // Задание 4
        int o = rnd.nextInt(100);
        int p = rnd.nextInt(100);
        int c = rnd.nextInt(100);
        int max = (o > p) ? (Math.max(o, c)) : (Math.max(p, c));
        System.out.println("Сгенерированные числа: " + o + ", " + p + ", " + c);
        System.out.println("Максимальное число: " + max);
    }
}
